﻿var AppName = "myApp";

(function (appName) {

    var app = angular.module(appName, []);

})(AppName);